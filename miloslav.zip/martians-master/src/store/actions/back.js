import { blankPost } from '../model.js'

// close editor and reset all its fields to default

export default (state, action) => state
  .set('paranja', false)
  .set('newPost', blankPost)
