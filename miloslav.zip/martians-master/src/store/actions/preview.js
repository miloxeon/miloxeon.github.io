// choose a post id to preview

export default (state, action) => state.set('preview', action.payload)
