// toggle aside menu

export default (state, action) => state.set('asideOpened', !state.get('asideOpened'))
