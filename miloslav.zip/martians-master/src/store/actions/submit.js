import nanoid from 'nanoid'
import { blankPost } from '../model.js'
import { fromJS, setIn, getIn } from 'immutable'

const create = (state, action) => setIn(
  state,
  ['posts'],
  fromJS(getIn(state, ['posts']).toJS().concat(
    Object.assign({},
      getIn(state, ['newPost']).toJS(), {
        id: nanoid(),
        text: getIn(state, ['newPost', 'text']).trim()
      }
    )
  ))
).set('newPost', blankPost)
.set('paranja', false)

const update = (state, action) => setIn(
  state,
  ['posts'],
  fromJS(
    getIn(state, ['posts']).toJS()
      .filter(post => post.id !== getIn(state, ['newPost', 'id']))
      .concat([getIn(state, ['newPost']).toJS()])
  )
).set('newPost', blankPost)
.set('paranja', false)

export default (state, action) => typeof getIn(state, ['newPost', 'id']) === 'undefined' ?
  create(state, action) :
  update(state, action)
