import { fromJS } from 'immutable'

export default (state, action) => state.set('posts',
  fromJS(state
    .get('posts')
    .toJS()
    .filter(
      post => post.id !== action.payload
    )
  )
)
