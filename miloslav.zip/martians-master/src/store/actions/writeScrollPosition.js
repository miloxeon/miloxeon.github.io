export default (state, action) => state.set('scrollPosition', action.payload)
