// set saved scroll Y to 0

export default (state, action) => state.set('scrollPosition', 0)
