export default (state, action) => state.set('scrollPosition', 0)
