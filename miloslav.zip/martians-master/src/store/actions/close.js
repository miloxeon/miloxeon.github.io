// close post preview

export default (state, action) => state.set('preview', null)
