import React from 'react'
import { ReactComponent as Close } from './assets/close.svg'
import Target from './target.js'
import { now } from './logic.js'
import styles from './styles.module.css'

const getRootStyles = mobile => [
  styles.root,
  mobile ? styles.mobile : ''
].join(' ')

const createSubmitHandler = callback => e => {
  e.preventDefault()
  callback()
}

export default props => (
  <div className={ getRootStyles(props.mobile) }>
    <header className={ styles.header }>
      <h2 className={ styles.heading }>
        New post
      </h2>
      <button
        type="button"
        className={ styles.close }
        onClick={ props.actions.back }
      >
        Close
        <Close className={ styles.icon } />
      </button>
    </header>
    <form
      className={ styles.main }
      onSubmit={ createSubmitHandler(props.actions.submit) }
    >
      <div className={ styles.when }>
        <label className={ styles.label }>
          When to publish:
        </label>
        <input
          className={ styles.input }
          type="date"
          name="date"
          autoFocus={ true }
          value={ props.post.date }
          onChange={ props.actions.commit('date') }
          required={ true }
        />
        <span className={ styles.at }>
          at
        </span>
        <input
          className={ styles.input }
          type="time"
          name="time"
          value={ props.post.time || now() }
          onChange={ props.actions.commit('time') }
          required={ true }
        />
        <small className={ styles.utc }>
          utc+03:00
        </small>
      </div>
      <div className={ styles.omnibox }>
        <div className={ styles.targets }>
          <Target avatar={ props.avatar } targets={ props.post.targets } handler={ props.actions.toggleTarget } name="facebook" />
          <Target avatar={ props.avatar } targets={ props.post.targets } handler={ props.actions.toggleTarget } name="twitter" />
          <Target avatar={ props.avatar } targets={ props.post.targets } handler={ props.actions.toggleTarget } name="googleplus" />
          <Target avatar={ props.avatar } targets={ props.post.targets } handler={ props.actions.toggleTarget } name="instagram" />
          <Target avatar={ props.avatar } targets={ props.post.targets } handler={ props.actions.toggleTarget } name="youtube" />
        </div>
        <textarea
          className={ styles.textarea }
          name="text"
          placeholder="Text and links"
          value={ props.post.text }
          onChange={ props.actions.commit('text') }
          required={ true }
        ></textarea>
      </div>
      <footer className={ styles.footer }>
        <button
          type="button"
          className={ styles.button }
        >
          Save as draft
        </button>
        <button
          type="submit"
          className={ styles.button }
          disabled={ !props.submitAllowed }
        >
          Schedule post
        </button>
      </footer>
    </form>
  </div>
)
