export const now = () => new Date().toISOString().split('T')[1].split(':').slice(0, 2).join(':')
