import React from 'react'
import styles from './styles.module.css'
import Page from '../../containers/page.js'
import Panes from '../../containers/panes.js'
import Paranja from '../../containers/paranja.js'
import Creator from '../../containers/creator.js'

import avatar from './assets/avatar.png'

export default props => (
  <div className={ styles.root }>
    <Page aside={ "Aside content will be there" }>
      <Panes avatar={ avatar } />
    </Page>
    <Paranja>
      <Creator avatar={ avatar } />
    </Paranja>
  </div>
)
