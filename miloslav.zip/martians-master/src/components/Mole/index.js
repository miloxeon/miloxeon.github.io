import React from 'react'
import styles from './styles.module.css'

const getRootStyles = (mobile, type) => [
  styles.root,
  mobile ? styles.mobile : '',
  styles[type]
].join(' ')

export default props => (
  <div className={ getRootStyles(props.mobile, props.type) }>
    { props.children }
  </div>
)
