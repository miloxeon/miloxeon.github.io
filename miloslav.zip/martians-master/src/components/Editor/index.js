import React from 'react'
import Target from './target.js'
import Closer from './closer.js'
import { getRootStyles, getDraftButtonStyles, getInputStyles } from './deciders.js'
import styles from './styles.module.css'

import { ReactComponent as Clear } from './assets/clear.svg'

import {
  now,
  today,
  createSubmitHandler,
  createToggleTargetHandler,
  createDateChangeHandler,
  createTimeChangeHandler
} from './logic.js'

export default props => (
  <div className={ getRootStyles(props.mobile) }>
    <header className={ styles.header }>
      <h2 className={ styles.heading }>
        { props.editing ? 'Edit post' : 'New post' }
      </h2>
      <div className={ styles.pillbox }>
        <button
          type="reset"
          className={ styles.action }
          onClick={ props.actions.clear }
        >
          Clear
          <Clear className={ [styles.icon, styles.clear].join(' ') } />
        </button>
        <button
          type="button"
          className={ styles.action }
          onClick={ props.actions.back }
          title={ props.editing ? 'Back to preview' : 'Close editor' }
        >
          Close
          <Closer editing={ props.editing } />
        </button>
      </div>
    </header>
    <form
      className={ styles.main }
      onSubmit={ createSubmitHandler(props.actions.submit) }
    >
      <div className={ styles.when }>
        <div className={ styles.datetime }>
          <label className={ styles.label }>
            When to publish:
          </label>
          <input
            className={ getInputStyles(props.errors.datetime) }
            type="date"
            name="date"
            value={ props.post.date || today() }
            onChange={ createDateChangeHandler(props.actions) }
            aria-invalid={ props.errors.datetime }
            required={ true }
            autoFocus={ !props.mobile }
          />
          <span className={ styles.at }>
            at
          </span>
          <input
            className={ getInputStyles(props.errors.datetime) }
            type="time"
            name="time"
            value={ props.post.time || now() }
            onChange={ createTimeChangeHandler(props.actions) }
            aria-invalid={ props.errors.datetime }
            required={ true }
          />
          <small className={ styles.utc }>
            utc+03:00
          </small>
        </div>
        <div
          className={ [styles.errors, styles.when_footer].join(' ') }
          hidden={ !props.errors.datetime }
        >
          { props.errors.datetime }
        </div>
      </div>
      <div className={ styles.omnibox }>
        <div className={ styles.targets_wrapper }>
          <div className={ styles.targets }>
            <Target
              avatar={ props.avatar }
              targets={ props.post.targets }
              handler={ createToggleTargetHandler(props.actions) }
              name="facebook"
            />

            <Target
              avatar={ props.avatar }
              targets={ props.post.targets }
              handler={ createToggleTargetHandler(props.actions) }
              name="twitter"
            />

            <Target
              avatar={ props.avatar }
              targets={ props.post.targets }
              handler={ createToggleTargetHandler(props.actions) }
              name="googleplus"
            />

            <Target
              avatar={ props.avatar }
              targets={ props.post.targets }
              handler={ createToggleTargetHandler(props.actions) }
              name="instagram"
            />

            <Target
              avatar={ props.avatar }
              targets={ props.post.targets }
              handler={ createToggleTargetHandler(props.actions) }
              name="youtube"
            />
          </div>
          <div
            className={ [styles.errors, styles.targets_footer].join(' ') }
            hidden={ !props.errors.targets }
          >
            { props.errors.targets }
          </div>
        </div>
        <textarea
          className={ styles.textarea }
          name="text"
          placeholder="Text and links"
          value={ props.post.text }
          onChange={ props.actions.commit('text') }
          required={ true }
        ></textarea>
      </div>
      <footer className={ styles.footer }>
        <button
          type="button"
          className={ getDraftButtonStyles(props.editing) }
        >
          Save as draft
        </button>
        <button
          type="submit"
          className={ styles.button }
          disabled={ !props.submitAllowed }
        >
          { props.editing ? 'Save changes' : 'Schedule post' }
        </button>
      </footer>
    </form>
  </div>
)
