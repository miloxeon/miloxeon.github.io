import React from 'react'
import styles from './styles.module.css'
import { ReactComponent as Menu } from './assets/menu.svg'

const getRootStyles = (mobile, inert) => [
  styles.root,
  mobile ? styles.mobile : '',
  inert ? styles.inert : ''
].join(' ')

const getMainStyles = asideOpened => [
  styles.main,
  asideOpened ? styles.inert : ''
].join(' ')

export default props => (
  <div
    className={ getRootStyles(props.mobile, props.inert) }
    hidden={ props.mobile && props.inert }
  >
    <button
      className={ styles.menu }
      onClick={ props.toggleMenu }
    >
      <Menu />
    </button>
    <aside
      className={ styles.aside }
      hidden={ props.mobile && !props.asideOpened }
    >
      <button
        className={ styles.menu }
        onClick={ props.toggleMenu }
      >
        <Menu className={ styles.invert } />
      </button>
      { props.aside }
    </aside>
    <main
      className={ getMainStyles(props.asideOpened) }
      hidden={ props.asideOpened }
    >
      { props.children }
    </main>
  </div>
)
