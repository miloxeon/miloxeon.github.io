import React from 'react'
import styles from './styles.module.css'

import { ReactComponent as Edit } from './assets/edit.svg'
import { ReactComponent as Close } from './assets/close.svg'
import { ReactComponent as Remove } from './assets/remove.svg'

export default props => props.published ? (
  <div className={ styles.summary }>
    <button
      className={ styles.control }
      onClick={ props.close }
    >
      Close
      <Close />
    </button>
  </div>
) : (
  <div className={ styles.summary }>
    <button
      className={ styles.control }
      onClick={ props.close }
    >
      Close
      <Close />
    </button>
    <button
      className={ styles.control }
      onClick={ props.edit }
    >
      Edit
      <Edit />
    </button>
    <button
      className={ styles.control }
      onClick={ props.remove }
    >
      Remove
      <Remove />
    </button>
  </div>
)
