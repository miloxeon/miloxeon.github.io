import React from 'react'
import styles from './styles.module.css'

const getRootStyles = mobile => [
  styles.root,
  mobile ? styles.mobile : ''
].join(' ')

export default props => (
  <div
    className={ getRootStyles(props.mobile) }
    hidden={ props.hidden }
  >
    { props.children }
  </div>
)
