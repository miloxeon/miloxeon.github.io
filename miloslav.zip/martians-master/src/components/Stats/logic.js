export const countPercents = (today, best) => (today / best) * 100 - 100
