import React from 'react'
import Stats from './stats.js'
import Actions from './actions.js'
import { Icon } from '../Icon'

import styles from './styles.module.css'

const getRootStyles = mobile => [
  styles.root,
  mobile ? styles.mobile : ''
].join(' ')

export default props => (
  <div className={ getRootStyles(props.mobile) }>
    <header className={ styles.header }>
      <h2 className={ styles.heading }>
        Post preview
      </h2>
      <Actions
        published={ props.post.published }
        close={ props.close }
        edit={ () => props.edit(props.post.id) }
        remove={ () => props.remove(props.post.id) }
      />
    </header>
    <div className={ styles.main }>
      <div className={ styles.summary }>
        <aside className={ styles.meta }>
          { props.post.published ? 'Published at ' : 'Scheduled at ' }
          <span className={ styles.datetime }>
            { props.post.date + ', ' + props.post.time }
          </span>
        </aside>
        <div className={ styles.targets }>
          { (props.post.targets || []).map(target => (
              <Icon brand={ target } key={ target } />
          )) }
        </div>
      </div>
      <p className={ styles.text }>
        { props.post.text }
      </p>
    </div>
    <Stats
      hidden={ !props.post.published }
      likes={ props.post.likes }
      comments={ props.post.comments }
      reposts={ props.post.reposts }
      views={ props.post.views }
    />
  </div>
)
