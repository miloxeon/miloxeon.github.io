import React from 'react'
import styles from './styles.module.css'
import Card from '../Card'
import Slot from '../Slot'
import Mole from '../Mole'

import slots from './slots.json'

import { wrapPosts } from './logic.js'

const createPostWrapper = globals => post => post.slot ? (
  <Mole
    type="subtle"
    key={ post.id }
    mobile={ globals.mobile }
  >
    <Slot
      time={ post.time }
      label={ post.text }
      mobile={ globals.mobile }
      onClick={ () => globals.actions.add(post.time, globals.date) }
    />
  </Mole>
) : (
  <Mole
    type="opaque"
    key={ post.id }
    mobile={ globals.mobile }
  >
    <Card
      time={ post.time }
      avatar={ globals.avatar }
      mobile={ globals.mobile }
      preview={ post.id === globals.preview }
      published={ post.published }
      targets={ post.targets }
      onClick={
        globals.mobile ?
        () => globals.actions.preview(post.id) :
        () => !post.published ? globals.actions.edit(post.id) : {}
      }
      edit={ () => !post.published ? globals.actions.edit(post.id) : {} }
      close={ globals.actions.close }
      remove={ () => globals.actions.remove(post.id) }
    >
      { post.text }
    </Card>
  </Mole>
)

const getRootStyles = mobile => [
  styles.root,
  mobile ? styles.mobile : ''
].join(' ')

export default props => (
  <div className={ getRootStyles(props.mobile) }>
    { wrapPosts(createPostWrapper, props.posts || [], slots, {
        mobile: props.mobile,
        preview: props.preview,
        actions: props.actions,
        avatar: props.avatar,
        date: props.date
    }) }
  </div>
)
