import React from 'react'
import Component from '../components/Paranja'
import { connect } from 'react-redux'

class Paranja extends React.Component {
  render() {
    return (
      <Component { ...this.props }>
        { this.props.children }
      </Component>
    )
  }
}

export default connect(
  state => ({
    mobile: state.get('mobile'),
    hidden: !state.get('paranja')
  })
)(Paranja)
