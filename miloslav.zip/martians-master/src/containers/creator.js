import React from 'react'
import Component from '../components/Creator'
import { connect } from 'react-redux'


const now = () => new Date().toISOString().split('T')[1].split(':').slice(0, 2).join(':')
const today = () => new Date().toISOString().split('T')[0]

const dateToDays = tuple => parseInt((tuple[0] * 12 * 30) + (tuple[1] * 30) + tuple[2])
const timeToMinutes = tuple => parseInt((tuple[0] * 60) + tuple[1])

const laterDate = (a, b) => {
  const daysA = dateToDays(a.split('-'))
  const daysB = dateToDays(b.split('-'))
  return daysA > daysB
}

const laterTime = (a, b) => {
  const minutesA = timeToMinutes(a.split(':'))
  const minutesB = timeToMinutes(b.split(':'))
  return minutesA > minutesB
}

const validateDateTime = (date, time) =>
  date &&
  time &&
  (laterDate(date, today()) || date === today()) &&
  (date === today() ? laterTime(time, now()) : true)

const checkIfSubmitAllowed = post =>
  validateDateTime(post.date, post.time) &&
  (post.text.trim().length !== 0) &&
  (post.targets.length > 0)



class Creator extends React.Component {
  render() {
    return (
      <Component { ...this.props } />
    )
  }
}


export default connect(
  state => ({
    mobile: state.get('mobile'),
    post: state.get('newPost').toJS(),
    submitAllowed: checkIfSubmitAllowed(state.get('newPost').toJS())
  }),
  dispatch => ({ actions: {
    back: () => dispatch({
      type: 'back'
    }),
    submit: () => dispatch({
      type: 'submit'
    }),
    commit: path => e => dispatch({
      type: 'commit',
      payload: {
        path: path,
        value: e.target.value
      }
    }),
    toggleTarget: target => dispatch({
      type: 'toggle_target',
      payload: target
    })
  }})
)(Creator)
